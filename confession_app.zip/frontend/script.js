document.getElementById("confessionForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const confession = document.getElementById("confession").value;
  const media = document.getElementById("media").files[0];
  const anonymous = document.getElementById("anonymous").checked;

  const formData = new FormData();
  formData.append("confession", confession);
  formData.append("media", media);
  formData.append("anonymous", anonymous);

  const response = await fetch("http://localhost:5000/submit", {
    method: "POST",
    body: formData,
  });

  if (response.ok) {
    document.getElementById("successMessage").style.display = "block";
    document.getElementById("confessionForm").reset();
  }
});
