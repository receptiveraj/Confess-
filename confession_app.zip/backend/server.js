const express = require("express");
const multer = require("multer");
const app = express();

// Configure multer for file uploads
const upload = multer({ dest: "uploads/" });

// Route to handle form submissions
app.post("/submit", upload.single("media"), (req, res) => {
  const { confession, anonymous } = req.body;
  const file = req.file;

  // Log data (replace this with database storage in production)
  console.log("Confession:", confession);
  console.log("Anonymous:", anonymous === "true");
  console.log("File:", file);

  res.status(200).send("Confession submitted successfully.");
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
